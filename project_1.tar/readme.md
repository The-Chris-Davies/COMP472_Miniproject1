# COMP 472 Miniproject 1

This is my submission for the COMP 472 miniproject 1, for the team "Categorization Pedant". I certify it meets the originality standards set out in yadda yadda etc.

**********

## Execution:
### Directory Setup: 
The python scripts expect to be in the same directory as a folder named `data`, which contains the extracted BBC dataset `BBC/` and the file `drug200.csv`.

### Running the tasks:
To execute the project, call them from your shell of choice:
```
python task_1.py
python task_2.py
```
